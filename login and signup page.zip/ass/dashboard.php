<!-- dashboard.php -->
<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to login page
    header("Location: login.php");
    exit();
}

// Display greeting with user's name
$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard, <span class="greeting"><?php echo $user_name; ?></span>!</h2>
        <!-- Dashboard content goes here -->
        <form action="./login.php" method="post">
            <input type="submit" value="Logout" class="logout-btn">
        </form>
    </div>
</body>
</html>
